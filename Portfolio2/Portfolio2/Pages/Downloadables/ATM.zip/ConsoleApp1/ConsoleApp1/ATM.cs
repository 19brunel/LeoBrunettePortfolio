﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SafeNetProblem
{
    class ATM
    {
        private int b100;
        private int b50;
        private int b20;
        private int b10;
        private int b5;
        private int b1;
        public ATM()
        {
            b100 = 10;
            b50 = 10;
            b20 = 10;
            b10 = 10;
            b5 = 10;
            b1 = 10;
        }

        public void Restock()
        {
            b100 = 10;
            b50 = 10;
            b20 = 10;
            b10 = 10;
            b5 = 10;
            b1 = 10;
        }
        public int Getb100()
        {
            return b100;
        }
        public int Getb50()
        {
            return b50;
        }
        public int Getb20()
        {
            return b20;
        }
        public int Getb10()
        {
            return b10;
        }
        public int Getb5()
        {
            return b5;
        }
        public int Getb1()
        {
            return b1;
        }
        public void Balance()
        {
            Console.WriteLine("ATM Balance:");
            Console.WriteLine("$100: "+b100);
            Console.WriteLine("$50: " + b50);
            Console.WriteLine("$20: " + b20);
            Console.WriteLine("$10: " + b10);
            Console.WriteLine("$5: " + b5);
            Console.WriteLine("$1: " + b1);
            Console.WriteLine();
        }
        public int GetTotal()
        {
            int total = (b100 * 100) + (b50 * 50) + (b20 * 20) + (b10 * 10) + (b5 * 5) + (b1);
            return total;
        }
        public Boolean Withdraw(int amount)
        {
            ATM copy = this.Clone();
            List<int> info = GetDenoms();
            Boolean cont = true;
            while (amount > 0)
            {
                cont = true;
                if (amount >= 100 && cont)
                {
                    if (b100 == 0)
                    {
                        SetAllDenoms(info);
                        return false;
                    }
                    else
                    {
                        amount -= 100;
                        b100 -= 1;
                        cont = false;
                    }
                }
                if (amount >= 50 && cont)
                {
                    if (b50 == 0)
                    {
                        SetAllDenoms(info);
                        return false;
                    }
                    else
                    {
                        amount -= 50;
                        b50 -= 1;
                        cont = false;
                    }
                }
                if (amount >= 20 && cont)
                {
                    if (b20 == 0)
                    {
                        SetAllDenoms(info);
                        return false;
                    }
                    else
                    {
                        amount -= 20;
                        b20 -= 1;
                        cont = false;
                    }
                }
                if (amount >= 10 && cont)
                {
                    if (b10 == 0)
                    {
                        SetAllDenoms(info);
                        return false;
                    }
                    else { 
                    amount -= 10;
                    b10 -= 1;
                    cont = false;
                    }
                }
                if (amount >= 5 && cont)
                {
                    if (b5 == 0)
                    {
                        SetAllDenoms(info);
                        return false;
                    }
                    else
                    {
                        amount -= 5;
                        b5 -= 1;
                        cont = false;
                    }
                }
                if (amount >= 1 && cont)
                {
                    if (b1 == 0)
                    {
                        SetAllDenoms(info);
                        return false;
                    }
                    else
                    {
                        amount -= 1;
                        b1 -= 1;
                        cont = false;
                    }
                }
            }
            return true;
        }
        public List<int> GetDenoms()
        {
            List<int> denoms = new List<int>();
            denoms.Add(b100);
            denoms.Add(b50);
            denoms.Add(b20);
            denoms.Add(b10);
            denoms.Add(b5);
            denoms.Add(b1);
            return denoms;
        }
        public void SetAllDenoms(List<int> amounts)
        {
            b100 = amounts[0];
            b50 = amounts[1];
            b20 = amounts[2];
            b10 = amounts[3];
            b5 = amounts[4];
            b1 = amounts[5];
        }
        public ATM Clone()
        {
            return this;
        }
    }
}
