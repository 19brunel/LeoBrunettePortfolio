﻿using System;
using System.Collections.Generic;

namespace SafeNetProblem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to command-line ATM. Type Command:");
            Boolean run = true;
            Boolean ran = false;
            ATM atm = new ATM();
            while (run)
            {
                if (ran)
                {
                    Console.WriteLine("Type Command:");
                }
                else
                {
                    Console.WriteLine("(Type 'help' for list of commands.)");
                }
                ran = true;
                string input = Console.ReadLine();
                string command = "";
                if (input.Length == 1)
                {
                    command = input.ToUpper();
                }
                else
                {
                    command = input.Split(" ")[0].ToUpper();
                }
                if(input.Contains(" ")==false && input.Contains("$") == false && input.Length==4)
                {
                    command = input.ToLower();
                }
                switch (command)
                {
                    case "R":
                        atm.Restock();
                        Console.WriteLine("ATM Restocked.");
                        atm.Balance();
                        break;
                    case "Q":
                        Console.WriteLine("Are you sure you would like to quit? (y/n)");
                        string choice = Console.ReadLine();
                        switch (choice)
                        {
                            case "y":
                                Console.WriteLine("Quitting ATM...");
                                run = false;
                                break;
                            case "n":
                                run = true;
                                break;
                            default:
                                run = true;
                                break;
                        }
                        break;
                    case "W":
                        if(input.Split(" ").Length>2)
                        {
                            Console.WriteLine("Invalid Format.Type 'help' for list of commands.");
                        }else
                        {
                            if (input.Split(" ")[1].Contains("$"))
                            {
                                int toWithdraw = int.Parse(input.Split(" ")[1].Substring(1));
                                if (toWithdraw > atm.GetTotal())
                                {
                                    Console.WriteLine("Insufficient funds.");
                                }
                                else
                                {
                                    Boolean complete = atm.Withdraw(toWithdraw);
                                    if (complete)
                                    {
                                        Console.WriteLine("$" + toWithdraw + " Dollars were withdrawn.");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Insufficient funds.");
                                    }
                                }
                                atm.Balance();
                            }
                            else
                            {
                                Console.WriteLine("Invalid Format.Type 'help' for list of commands.");
                            }
                        }
                        break;
                    case "I":
                        string[] inputArr = input.Split(" ");
                        List<int> denoms = new List<int>();
                        for(int i = 1;i<inputArr.Length;i++)
                        {
                            switch (int.Parse(inputArr[i].Substring(1)))
                            {
                                case 100:
                                    Console.WriteLine("$100: "+atm.Getb100());
                                    break;
                                case 50:
                                    Console.WriteLine("$50: " + atm.Getb50());
                                    break;
                                case 20:
                                    Console.WriteLine("$20: " + atm.Getb20());
                                    break;
                                case 10:
                                    Console.WriteLine("$10: " + atm.Getb10());
                                    break;
                                case 5:
                                    Console.WriteLine("$5: " + atm.Getb5());
                                    break;
                                case 1:
                                    Console.WriteLine("$1: " + atm.Getb1());
                                    break;
                                default:
                                    Console.WriteLine("Invalid Denomination. Type 'help' for list of commands.");
                                    break;
                            }
                            Console.WriteLine();
                        }
                        break;
                    case "help":
                        Console.WriteLine();
                        Console.WriteLine("R - Restockes the ATM to the original pre-stock levels. Use: 'R'");
                        Console.WriteLine("W <dollar amount> - Withdraws amount from ATM. Use: 'W $145'");
                        Console.WriteLine("I<denominations> - Displays the number of bills in that denomination present in the ATM. Use: 'I'");
                        Console.WriteLine("Q - Quits the application. Use: 'Q'");
                        Console.WriteLine("Help - Displays this screen. Use: 'help'");
                        Console.WriteLine();
                        break;
                    default:
                        Console.WriteLine("Invalid Command. Type 'help' for list of commands.");
                        break;
                }
            }
            Console.WriteLine("(Press any key to close.)");
            Console.ReadKey();
        }
    }
}
